USE master
GO

IF EXISTS (SELECT * FROM sys.server_principals WHERE name = 'PromoteApp')
	DROP LOGIN [PromoteApp]
GO

CREATE LOGIN PromoteApp WITH PASSWORD = 'Pa$$w0rd', CHECK_EXPIRATION=OFF, CHECK_POLICY=ON;
GO

ALTER LOGIN PromoteApp DISABLE
GO

