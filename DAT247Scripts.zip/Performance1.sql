USE AdventureWorks2012;
GO
BEGIN TRAN; UPDATE Purchasing.ShipMethod SET name = N'XRQ - TRUCK' WHERE shipmethodid = 1;

