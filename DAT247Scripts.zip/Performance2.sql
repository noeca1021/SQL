USE AdventureWorks2012;
GO
BEGIN TRAN; SELECT * FROM Purchasing.ShipMethod AS sm WITH (REPEATABLEREAD) JOIN Sales.SalesOrderHeader AS soh ON sm.shipmethodid = soh.shipmethodid; COMMIT;


